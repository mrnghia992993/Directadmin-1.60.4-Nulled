#!/bin/sh
OS=`uname`
BIN_PS=/bin/ps
if [ -x ${BIN_PS} ]; then
	echo "Top Memory Usage:"
	${BIN_PS} aux | sort -r -nk 4 | head
fi

VMSTAT=/usr/bin/vmstat
if [ -x ${VMSTAT} ]; then
	echo ""
	echo "Virtual Memory Info:"
	
	if [ "${OS}" = "FreeBSD" ]; then
		${VMSTAT} 1 3
	else
		HAS_TIMESTAMP=`${VMSTAT} --help 2>&1 | grep -c '\-t'`
	
		if [ "${HAS_TIMESTAMP}" = "0" ]; then
			date
			${VMSTAT} -w 1 3
			date
		else
			${VMSTAT} -tw 1 3
		fi
	fi
fi

exit 0;